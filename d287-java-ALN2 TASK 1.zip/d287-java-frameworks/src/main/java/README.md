# WESTERN GOVERNORS UNIVERSITY 
## D287 – JAVA FRAMEWORKS

### Part C: Update `mainscreen.html`

**Description:**

Changes were made to improve the visual design of the `mainscreen.html` file.

**Code Changes:**

- **File:** `mainscreen.html`
    - **Line 16:** Changed the background color to dimgrey to improve readability.
    - **Line 21:** Set header color to light for better contrast against the darker background.
    - **Line 34:** Updated table head color to light for better visibility.
    - **Line 35:** Added "About Us" button for navigation to the `about.html` page.
    - **Line 53:** Set another header to light color to match the overall styling.
    - **Line 70:** Set table head color to light to ensure consistent styling.

---

### Part D: Add an "About" page

**Description:**

A new "About Us" page was created to provide users with details about the business.

**Code Changes:**

- **File:** `about.html`
    - **Line 16:** Set background to dimgrey to match the main screen’s style.
    - **Line 21:** Set header color to light for consistency.
    - **Line 28:** Applied text-light class to paragraphs for better readability.
    - **Line 43:** Added a navigation link to return to the main screen using button styling.

- **File:** `AboutController.java`
    - Created a controller to map `/about` to the `about.html` page and enable navigation between the main screen and the "About Us" page.

---

### Part E: Add sample inventory

**Description:**

Sample inventory was added, consisting of five parts and five products, while ensuring no existing data was overwritten.

**Code Changes:**

- **File:** `BootStrapData.java`
    - **Line 32-40:** Added logic to check if the parts and product lists are empty before populating the sample inventory.
    - **Line 45-65:** Added sample parts with minimum and maximum inventory values.
    - **Line 75-95:** Added five sample products to the inventory.
    - **Multi-Pack Handling:** Created "multi-pack" parts if duplicate parts were detected.

---

### Part F: Add "Buy Now" button

**Description:**

A "Buy Now" button was added to the product list to allow users to purchase products, which decrements the product inventory.

**Code Changes:**

- **File:** `mainscreen.html`
    - **Line 65:** Added a "Buy Now" button next to the update and delete buttons in the product table. The button sends a POST request to `/buyProduct` with the product ID via a hidden input field.

- **File:** `BuyProductController.java`
    - **Line 12-45:** Created a controller to handle product purchases. The controller retrieves the product by ID, decrements the inventory by one, and saves the updated product. Success or failure messages are displayed based on inventory availability.

---

### Part G: Track maximum and minimum inventory

**Description:**

Fields for `maxInv` and `minInv` were added to the `Part` entity, and validation was enforced to ensure inventory stays within these values.

**Code Changes:**

- **File:** `Part.java`
    - **Line 30:** Added `minInv` and `maxInv` fields to track the minimum and maximum inventory values.
    - **Line 70:** Added getter and setter methods for `minInv` and `maxInv`.

- **File:** `BootStrapData.java`
    - **Line 45-65:** Updated the sample inventory to include realistic minimum and maximum inventory values for each part.

- **File:** `InhousePartForm.html`
    - **Line 45-55:** Added input fields for `minInv` and `maxInv` to allow users to set inventory constraints when adding or updating in-house parts.

- **File:** `OutsourcedPartForm.html`
    - **Line 45-55:** Added input fields for `minInv` and `maxInv` to allow users to set inventory constraints when adding or updating outsourced parts.

- **File:** `application.properties`
    - **Line 1:** Renamed the database file and updated the application to reflect the new database file name.

- **Files:** `AddInhousePartController.java` and `AddOutsourcedPartController.java`
    - **Line 25-45:** Updated the controllers to enforce the inventory constraints between `minInv` and `maxInv`.

---

### Part H: Add validation for inventory constraints

**Description:**

Validation logic was added to ensure that inventory remains within the allowed range, and specific error messages were displayed for violations.

**Code Changes:**

- **File:** `AddInhousePartController.java`
    - **Line 25-45:** Added validation to display specific error messages if the inventory is below the minimum (`minInv`) or above the maximum (`maxInv`).

- **File:** `AddOutsourcedPartController.java`
    - **Line 25-45:** Added validation to display specific error messages if the inventory is below the minimum (`minInv`) or above the maximum (`maxInv`).

- **File:** `EnufPartsValidator.java`
    - **Line 30-50:** Updated validation to ensure that product updates do not reduce any associated part’s inventory below its minimum.

- **File:** `ValidEnufParts.java`
    - **Line 10:** Updated the default error message in the `@ValidEnufParts` annotation to reflect potential inventory issues related to product updates.

---

### Part I: Add unit tests for max and min inventory

**Description:**

Two unit tests were added to the `PartTest` class to verify the correct behavior of the `minInv` and `maxInv` fields.

**Code Changes:**

- **File:** `PartTest.java`
    - **Line 100-120:** Added a test to verify the correct behavior of the `minInv` field using `assertEquals()`.
    - **Line 125-145:** Added a test to verify the correct behavior of the `maxInv` field using `assertEquals()`.

---

### Part J: Summary of Changes

**Description:**

Unused validator class file was removed to clean up the code and ensure the project only includes necessary and relevant code.

**Code Changes:**

- **File:** `DeletePartValidator.java`
  - The `DeletePartValidator` class was identified as unused, with no usages in the codebase, and was subsequently deleted to improve code cleanliness..