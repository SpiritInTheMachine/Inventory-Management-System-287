package com.example.demo.bootstrap;

import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;

    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        if (partRepository.count() == 0 && productRepository.count() == 0) {

            //Set for avoiding addition of duplicates
            Set<String> partNames = new HashSet<>();
            Set<String> productNames = new HashSet<>();

            //Part samples
            OutsourcedPart part1 = new OutsourcedPart();
            part1.setCompanyName("WGU");
            part1.setName("Gear");
            part1.setInv(12);
            part1.setPrice(8.99);
            part1.setMinInv(4);
            part1.setMaxInv(19);

            OutsourcedPart part2 = new OutsourcedPart();
            part2.setCompanyName("Organization 13");
            part2.setName("Pedal");
            part2.setInv(17);
            part2.setPrice(10.99);
            part2.setMinInv(5);
            part2.setMaxInv(19);

            OutsourcedPart part3 = new OutsourcedPart();
            part3.setCompanyName("Shinra Electric Power Company");
            part3.setName("Chain");
            part3.setInv(8);
            part3.setPrice(12.99);
            part3.setMinInv(6);
            part3.setMaxInv(20);

            OutsourcedPart part4 = new OutsourcedPart();
            part4.setCompanyName("Umbrella Corporation");
            part4.setName("Handle");
            part4.setInv(5);
            part4.setPrice(9.99);
            part4.setMinInv(2);
            part4.setMaxInv(18);

            OutsourcedPart part5 = new OutsourcedPart();
            part5.setCompanyName("Mishima Zaibatsu");
            part5.setName("Brake");
            part5.setInv(15);
            part5.setPrice(11.99);
            part5.setMinInv(5);
            part5.setMaxInv(25);

            // Add to set & repository handle duplicates
            if (!partNames.add(part1.getName())) {
                part1.setName(part1.getName() + " Multi-Pack");
            }
            outsourcedPartRepository.save(part1);

            if (!partNames.add(part2.getName())) {
                part2.setName(part2.getName() + " Multi-Pack");
            }
            outsourcedPartRepository.save(part2);

            if (!partNames.add(part3.getName())) {
                part3.setName(part3.getName() + " Multi-Pack");
            }
            outsourcedPartRepository.save(part3);

            if (!partNames.add(part4.getName())) {
                part4.setName(part4.getName() + " Multi-Pack");
            }
            outsourcedPartRepository.save(part4);

            if (!partNames.add(part5.getName())) {
                part5.setName(part5.getName() + " Multi-Pack");
            }
            outsourcedPartRepository.save(part5);

            // Sample products
            Product product1 = new Product();
            product1.setName("Super Sylph B-503 Bike");
            product1.setPrice(299.99);
            product1.setInv(5);

            Product product2 = new Product();
            product2.setName("KOS-MOS KP-X Bike");
            product2.setPrice(399.99);
            product2.setInv(3);

            Product product3 = new Product();
            product3.setName("Metal Gear REX Bike");
            product3.setPrice(199.99);
            product3.setInv(8);

            Product product4 = new Product();
            product4.setName("Ultima χ-Bike");
            product4.setPrice(349.99);
            product4.setInv(4);

            Product product5 = new Product();
            product5.setName("Shinra No.26 Electric Bike");
            product5.setPrice(999.99);
            product5.setInv(2);

            // Add to set and repository (handle duplicates)
            if (!productNames.add(product1.getName())) {
                product1.setName(product1.getName() + " Multi-Pack");
            }
            productRepository.save(product1);

            if (!productNames.add(product2.getName())) {
                product2.setName(product2.getName() + " Multi-Pack");
            }
            productRepository.save(product2);

            if (!productNames.add(product3.getName())) {
                product3.setName(product3.getName() + " Multi-Pack");
            }
            productRepository.save(product3);

            if (!productNames.add(product4.getName())) {
                product4.setName(product4.getName() + " Multi-Pack");
            }
            productRepository.save(product4);

            if (!productNames.add(product5.getName())) {
                product5.setName(product5.getName() + " Multi-Pack");
            }
            productRepository.save(product5);
        }



       /*
        OutsourcedPart o= new OutsourcedPart();
        o.setCompanyName("Western Governors University");
        o.setName("out test");
        o.setInv(5);
        o.setPrice(20.0);
        o.setId(100L);
        outsourcedPartRepository.save(o);
        OutsourcedPart thePart=null;
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            if(part.getName().equals("out test"))thePart=part;
        }

        System.out.println(thePart.getCompanyName());
        */
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            System.out.println(part.getName()+" "+part.getCompanyName());
        }

        /*
        Product bicycle= new Product("bicycle",100.0,15);
        Product unicycle= new Product("unicycle",100.0,15);
        productRepository.save(bicycle);
        productRepository.save(unicycle);
        */

        System.out.println("Started in Bootstrap");
        System.out.println("Number of Products"+productRepository.count());
        System.out.println(productRepository.findAll());
        System.out.println("Number of Parts"+partRepository.count());
        System.out.println(partRepository.findAll());

    }
}
